package com.atguigu.edusta.service;

import com.atguigu.edusta.entity.StatisticsDaily;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.Map;

/**
 * <p>
 * 网站统计日数据 服务类
 * </p>
 *
 * @author testjava
 * @since 2021-04-08
 */
public interface StatisticsDailyService extends IService<StatisticsDaily> {

    //查询某一天注册人数
    void registerCount(String day);

    //图标显示，返回两部分数据，日期json格式，以及数量json格式
    Map<String, Object> getShowData(String type, String begin, String end);
}
